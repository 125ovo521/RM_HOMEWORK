// #ifndef MINING_INDUSTRY_HPP  
// #define MINING_INDUSTRY_HPP  

// #include "rclcpp/rclcpp.hpp"
// #include "gold_miner/msg/oreinfoarray.hpp"
// #include "geometry_msgs/msg/point.hpp"
// #include "std_msgs/msg/string.hpp"

// #include <vector>

// namespace gold_miner{
    
// class Publisher : public rclcpp::Node {
//     // using float32 = std_msgs::msg::Float32;
//     // using addTwoIntsSrv = example_interfaces::srvg::AddTwoInts;
    
//     //5.切割类的访问权限
//     public: //function
//     //7. 设计构造函数
//     Publisher(const std::string & name) : Node(name) {//构造函数需要初始化rclcpp::Node的构造函数
//         RCLCPP_INFO(this->get_logger(), "node:%s start!!",name.c_str()); //ROS2的log系统，除了需要get_logger()其他和printf用法差不多
        
//         //8.1 初始化 6.声明变量 中的变量
//         xxx_pub_ = this->create_publisher<float32>("your_topic_name",10);
//         //↓↓↓ 复习下cpp基础培训课上std::function 和 std::bind, std::bind()绑定类成员函数的用法例子如下，此函数返回std::function类型的函数
//         auto msg_callback = std::bind(&YourClassName::subMsgCallback, this, std::placeholders::_1);
//         xxx_sub_ = this->create_subscription<float32>("your_topic_name",10,msg_callback);//msg_callback需要理解他的写法和基本原理

//         xxx_client_ = this->create_client<addTwoIntsSrv>("your_topic_name");
//         using namespace std::placeholders; //省掉一些代码书写，这里是局部暂时使用，所以允许
//         //↓↓↓ 同上,还是callback
//         auto srv_callback = std::bind(&YourClassName::serverProcCallback, this, _1, _2);
//         xxx_server_ = this->create_service<addTwoIntsSrv>("your_service_name",srv_callback);
//     } 

//     private: //function
//     //8.2 回调函数,函数实现一般放在xxx_xxx.cpp文件
//     //topic - sub
//     void subMsgCallback(float32::SharedPtr num);
//     //service - server
//     void serverProcCallback(const std::shared_ptr<addTwoIntsSrv::Request> req, std::shared_ptr<addTwoIntsSrv::Response> res);
//     //service - client 发送request，需要根据自己的应用情况在恰当时机发送请求--->这个就参考fishros的教程吧，humble官方教程不是用的class，就不多说了


//     public: // var

//     private: // var
//     //6.声明node类成员变量
        
//         // Topic communication ： Publisher <---> Subscription >>> interface : msg
//         using float32 = std_msgs::msg::Float32;//也可直接放在类外，直接在整个class中都生效
//         rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr xxx_pub_; // topic publisher，
//         rclcpp::Subscription<float32>::SharedPtr xxx_sub_;
//         //续上 ↑ <ros-interface-show>里放的就是说的标准通信数据格式，也就是interface. 可以通过ros2 interface list 来看所有的interface
//         //续上 ↑ 如果你想更换其他的interface，那就需要将他所在的pkg在cmake和package添加依赖，然后include头文件，然后再更换他
//         //续上 ↑ 如果觉得太长了那么可以使用  using float32 = std_msgs::msg::Float32;  来起简称
//         //续上 ↑ 紧接着, 将鼠标放在SharedPtr上，vscode应该也会提示一个using xxxxx = xxx, 我们写的那个东西也就是std::shared_ptr<rclcpp::Publisher<>>的简称
//         //续上 ↑ ,而这里的rclcpp::Publisher<type>其实就是一个类class，rclcpp::Publisher<type>::SharedPtr就是一个指向这个类对象的智能指针

//         //同理，根据需要可声明其他的通信实体类，如下
        
//         // Service communication ： Service <---> Client >>> interface : srv
//         rclcpp::Service<example_interfaces::srv::AddTwoInts>::SharedPtr xxx_server_;
//         rclcpp::Client<example_interfaces::srv::AddTwoInts>::SharedPtr xxx_client_;
//         //这里的 example_interfaces::srv::AddTwoInts是内置的srv，不同于msg，很多内置的srv不满足我们的应用要求，因此一般都需要自己定义-->>自定义interface

//         // 其他变量,随用户需要，such as : 
//         int num_;
//         double whatever_;
// };
// }


// #endif
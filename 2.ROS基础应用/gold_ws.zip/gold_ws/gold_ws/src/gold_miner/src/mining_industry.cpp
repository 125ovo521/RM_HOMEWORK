#include "rclcpp/rclcpp.hpp"
#include "gold_miner/msg/OreInfo.hpp"
#include "gold_miner/msg/OreArray.hpp"
#include "geometry_msgs/msg/point.hpp"

class MiningIndustry : public rclcpp::Node {
public:
	//������ʯ�����Ľڵ� 
    MiningIndustry() : Node("mining_industry") {
    	//���������ߣ�����������Ϊ "topic"
        publisher_ = this->create_publisher<gold_miner::msg::OreArray>("topic", 10);
        //�������񣬷��� Ϊ"ore_srv"��������Ӧ����Ҫ�Ŀ�ʯλ�� 
        service_ = this->create_service<gold_miner::srv::OrePosition>("ore_srv", std::bind(&MiningIndustry::srv, this, std::placeholders::_1));
        timer_ = this->create_wall_timer(
            std::chrono::seconds(1),
            std::bind(&MiningIndustry::publishOreInfo, this)
        );
        //��ȡ����n 
        this->declare_parameter("n", 10);
        this->get_parameter("n", n_);
    }

private:
    gold_miner::msg::OreArray ores;
    //������ʯλ�� 
    void publishOreInfo() {
        for (int64_t i = 1; i <= n_; ++i) {
            gold_miner::msg::OreInfo ore;
            ore.num = i;
            ore.type = (i % 2 == 0) ? "gold" : "silver";
            ore.position.x = RandomPosition();
            ore.position.y = RandomPosition();
            ore.position.z = RandomPosition();
            ore.value = (ore.type == "gold") ? -80.8 : -40.4;
            ores.ores.push_back(ore);
        }
        RCLCPP_INFO(this->get_logger(), "I send!");
        publisher_->publish(ores);
    }
    //�����������������ʯλ�� 
    void srv(const std::shared_ptr<gold_miner::srv::OrePosition::Request> request,
             std::shared_ptr<gold_miner::srv::OrePosition::Response> response) {
        int64_t  idd = request->id;
        reponse->position = ores[idd];
        RCLCPP_INFO(this->get_logger(), "x = %ld, y = %ld, z = %ld", response->position.x,response->position.y,response->position.z);
    }
    //��ʯ���λ�� 
    double RandomPosition() {
        return (rand() % 21)-10;
    }

    rclcpp::Publisher<gold_miner::msg::OreArray>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    int64_t n_;
    rclcpp::Service<gold_miner::srv::OrePosition>::SharedPtr service_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<MiningIndustry>());
    rclcpp::shutdown();
    return 0;
}



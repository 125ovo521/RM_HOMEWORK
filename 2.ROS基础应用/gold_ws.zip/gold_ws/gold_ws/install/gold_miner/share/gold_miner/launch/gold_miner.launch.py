import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    params_file = os.path.join(
        get_package_share_directory('gold_miner'),'config', 'params.yaml'
    )

    mining_industry = Node(
        package='gold_miner',
        executable = 'mining_industry',
        parameters = [params_file],
    )

    miner = Node(
        package='gold_miner',
        executable='miner',
        #parameters=[other_params_file],
    )

    ld = LaunchDescription([
        mining_industry,
        miner,
    ])
    return ld
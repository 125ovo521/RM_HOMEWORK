// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from gold_miner:msg/OreInfoArray.idl
// generated code does not contain a copyright notice
#include "gold_miner/msg/detail/ore_info_array__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `ores`
#include "gold_miner/msg/detail/ore_info__functions.h"

bool
gold_miner__msg__OreInfoArray__init(gold_miner__msg__OreInfoArray * msg)
{
  if (!msg) {
    return false;
  }
  // ores
  if (!gold_miner__msg__OreInfo__Sequence__init(&msg->ores, 0)) {
    gold_miner__msg__OreInfoArray__fini(msg);
    return false;
  }
  return true;
}

void
gold_miner__msg__OreInfoArray__fini(gold_miner__msg__OreInfoArray * msg)
{
  if (!msg) {
    return;
  }
  // ores
  gold_miner__msg__OreInfo__Sequence__fini(&msg->ores);
}

bool
gold_miner__msg__OreInfoArray__are_equal(const gold_miner__msg__OreInfoArray * lhs, const gold_miner__msg__OreInfoArray * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // ores
  if (!gold_miner__msg__OreInfo__Sequence__are_equal(
      &(lhs->ores), &(rhs->ores)))
  {
    return false;
  }
  return true;
}

bool
gold_miner__msg__OreInfoArray__copy(
  const gold_miner__msg__OreInfoArray * input,
  gold_miner__msg__OreInfoArray * output)
{
  if (!input || !output) {
    return false;
  }
  // ores
  if (!gold_miner__msg__OreInfo__Sequence__copy(
      &(input->ores), &(output->ores)))
  {
    return false;
  }
  return true;
}

gold_miner__msg__OreInfoArray *
gold_miner__msg__OreInfoArray__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  gold_miner__msg__OreInfoArray * msg = (gold_miner__msg__OreInfoArray *)allocator.allocate(sizeof(gold_miner__msg__OreInfoArray), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(gold_miner__msg__OreInfoArray));
  bool success = gold_miner__msg__OreInfoArray__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
gold_miner__msg__OreInfoArray__destroy(gold_miner__msg__OreInfoArray * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    gold_miner__msg__OreInfoArray__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
gold_miner__msg__OreInfoArray__Sequence__init(gold_miner__msg__OreInfoArray__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  gold_miner__msg__OreInfoArray * data = NULL;

  if (size) {
    data = (gold_miner__msg__OreInfoArray *)allocator.zero_allocate(size, sizeof(gold_miner__msg__OreInfoArray), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = gold_miner__msg__OreInfoArray__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        gold_miner__msg__OreInfoArray__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
gold_miner__msg__OreInfoArray__Sequence__fini(gold_miner__msg__OreInfoArray__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      gold_miner__msg__OreInfoArray__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

gold_miner__msg__OreInfoArray__Sequence *
gold_miner__msg__OreInfoArray__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  gold_miner__msg__OreInfoArray__Sequence * array = (gold_miner__msg__OreInfoArray__Sequence *)allocator.allocate(sizeof(gold_miner__msg__OreInfoArray__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = gold_miner__msg__OreInfoArray__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
gold_miner__msg__OreInfoArray__Sequence__destroy(gold_miner__msg__OreInfoArray__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    gold_miner__msg__OreInfoArray__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
gold_miner__msg__OreInfoArray__Sequence__are_equal(const gold_miner__msg__OreInfoArray__Sequence * lhs, const gold_miner__msg__OreInfoArray__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!gold_miner__msg__OreInfoArray__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
gold_miner__msg__OreInfoArray__Sequence__copy(
  const gold_miner__msg__OreInfoArray__Sequence * input,
  gold_miner__msg__OreInfoArray__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(gold_miner__msg__OreInfoArray);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    gold_miner__msg__OreInfoArray * data =
      (gold_miner__msg__OreInfoArray *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!gold_miner__msg__OreInfoArray__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          gold_miner__msg__OreInfoArray__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!gold_miner__msg__OreInfoArray__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}

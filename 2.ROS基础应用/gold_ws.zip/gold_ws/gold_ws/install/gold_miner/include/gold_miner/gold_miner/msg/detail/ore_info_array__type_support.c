// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from gold_miner:msg/OreInfoArray.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "gold_miner/msg/detail/ore_info_array__rosidl_typesupport_introspection_c.h"
#include "gold_miner/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "gold_miner/msg/detail/ore_info_array__functions.h"
#include "gold_miner/msg/detail/ore_info_array__struct.h"


// Include directives for member types
// Member `ores`
#include "gold_miner/msg/ore_info.h"
// Member `ores`
#include "gold_miner/msg/detail/ore_info__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  gold_miner__msg__OreInfoArray__init(message_memory);
}

void gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_fini_function(void * message_memory)
{
  gold_miner__msg__OreInfoArray__fini(message_memory);
}

size_t gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__size_function__OreInfoArray__ores(
  const void * untyped_member)
{
  const gold_miner__msg__OreInfo__Sequence * member =
    (const gold_miner__msg__OreInfo__Sequence *)(untyped_member);
  return member->size;
}

const void * gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__get_const_function__OreInfoArray__ores(
  const void * untyped_member, size_t index)
{
  const gold_miner__msg__OreInfo__Sequence * member =
    (const gold_miner__msg__OreInfo__Sequence *)(untyped_member);
  return &member->data[index];
}

void * gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__get_function__OreInfoArray__ores(
  void * untyped_member, size_t index)
{
  gold_miner__msg__OreInfo__Sequence * member =
    (gold_miner__msg__OreInfo__Sequence *)(untyped_member);
  return &member->data[index];
}

void gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__fetch_function__OreInfoArray__ores(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const gold_miner__msg__OreInfo * item =
    ((const gold_miner__msg__OreInfo *)
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__get_const_function__OreInfoArray__ores(untyped_member, index));
  gold_miner__msg__OreInfo * value =
    (gold_miner__msg__OreInfo *)(untyped_value);
  *value = *item;
}

void gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__assign_function__OreInfoArray__ores(
  void * untyped_member, size_t index, const void * untyped_value)
{
  gold_miner__msg__OreInfo * item =
    ((gold_miner__msg__OreInfo *)
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__get_function__OreInfoArray__ores(untyped_member, index));
  const gold_miner__msg__OreInfo * value =
    (const gold_miner__msg__OreInfo *)(untyped_value);
  *item = *value;
}

bool gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__resize_function__OreInfoArray__ores(
  void * untyped_member, size_t size)
{
  gold_miner__msg__OreInfo__Sequence * member =
    (gold_miner__msg__OreInfo__Sequence *)(untyped_member);
  gold_miner__msg__OreInfo__Sequence__fini(member);
  return gold_miner__msg__OreInfo__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_member_array[1] = {
  {
    "ores",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(gold_miner__msg__OreInfoArray, ores),  // bytes offset in struct
    NULL,  // default value
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__size_function__OreInfoArray__ores,  // size() function pointer
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__get_const_function__OreInfoArray__ores,  // get_const(index) function pointer
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__get_function__OreInfoArray__ores,  // get(index) function pointer
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__fetch_function__OreInfoArray__ores,  // fetch(index, &value) function pointer
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__assign_function__OreInfoArray__ores,  // assign(index, value) function pointer
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__resize_function__OreInfoArray__ores  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_members = {
  "gold_miner__msg",  // message namespace
  "OreInfoArray",  // message name
  1,  // number of fields
  sizeof(gold_miner__msg__OreInfoArray),
  gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_member_array,  // message members
  gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_init_function,  // function to initialize message memory (memory has to be allocated)
  gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_type_support_handle = {
  0,
  &gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_gold_miner
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, gold_miner, msg, OreInfoArray)() {
  gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, gold_miner, msg, OreInfo)();
  if (!gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_type_support_handle.typesupport_identifier) {
    gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &gold_miner__msg__OreInfoArray__rosidl_typesupport_introspection_c__OreInfoArray_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:srv/OrePosition.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__ORE_POSITION_H_
#define INTERFACES__SRV__ORE_POSITION_H_

#include "interfaces/srv/detail/ore_position__struct.h"
#include "interfaces/srv/detail/ore_position__functions.h"
#include "interfaces/srv/detail/ore_position__type_support.h"

#endif  // INTERFACES__SRV__ORE_POSITION_H_

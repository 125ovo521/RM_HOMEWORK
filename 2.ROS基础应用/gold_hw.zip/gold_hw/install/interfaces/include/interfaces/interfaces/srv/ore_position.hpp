// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__ORE_POSITION_HPP_
#define INTERFACES__SRV__ORE_POSITION_HPP_

#include "interfaces/srv/detail/ore_position__struct.hpp"
#include "interfaces/srv/detail/ore_position__builder.hpp"
#include "interfaces/srv/detail/ore_position__traits.hpp"

#endif  // INTERFACES__SRV__ORE_POSITION_HPP_

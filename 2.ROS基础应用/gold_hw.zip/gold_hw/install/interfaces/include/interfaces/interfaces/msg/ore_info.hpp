// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ORE_INFO_HPP_
#define INTERFACES__MSG__ORE_INFO_HPP_

#include "interfaces/msg/detail/ore_info__struct.hpp"
#include "interfaces/msg/detail/ore_info__builder.hpp"
#include "interfaces/msg/detail/ore_info__traits.hpp"

#endif  // INTERFACES__MSG__ORE_INFO_HPP_

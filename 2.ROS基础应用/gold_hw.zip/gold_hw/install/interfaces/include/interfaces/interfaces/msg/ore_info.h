// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:msg/OreInfo.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ORE_INFO_H_
#define INTERFACES__MSG__ORE_INFO_H_

#include "interfaces/msg/detail/ore_info__struct.h"
#include "interfaces/msg/detail/ore_info__functions.h"
#include "interfaces/msg/detail/ore_info__type_support.h"

#endif  // INTERFACES__MSG__ORE_INFO_H_

// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ORE_ARRAY_HPP_
#define INTERFACES__MSG__ORE_ARRAY_HPP_

#include "interfaces/msg/detail/ore_array__struct.hpp"
#include "interfaces/msg/detail/ore_array__builder.hpp"
#include "interfaces/msg/detail/ore_array__traits.hpp"

#endif  // INTERFACES__MSG__ORE_ARRAY_HPP_

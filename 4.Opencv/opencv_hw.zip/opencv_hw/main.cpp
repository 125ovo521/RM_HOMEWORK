#include <opencv2/imgcodecs.hpp>   
#include <opencv2/highgui.hpp>     
#include <opencv2/imgproc.hpp>     
#include <iostream>           

using namespace cv;              
using namespace std;             

Mat img;
vector<vector<int>> newPoints;
vector<Point> contourPoints;

vector<vector<int>> myColors { {0,110,153,19,240,255},// red_low
                                {100,150,50,255,150,255},//blue
                                {300,50,150,330,255,255}}; //pink

Point getContours(Mat imgDil){

    //contours轮廓（矢量），hierarchy层次结构，外部方法，方法（有链近似）
    vector<vector<Point>> contours;
    //有四个整数值 
    vector<Vec4i> hierarchy;
    
    findContours(imgDil, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    //画轮廓，-1为绘制所有，2为厚度
    //drawContours(img, contours, -1, Scalar(255, 0, 255), 2);

    vector<vector<Point>> conPoly(contours.size());
    vector<Rect> boundRect(contours.size());
    
    Point myPoint(0, 0);

    //找轮廓面积
    for(int i = 0; i < contours.size(); i++)
    {
        //获得过滤面积
        int area = contourArea(contours[i]);
        cout << area << endl;

        string objectType;
        //高于1000才画轮廓
        if (area > 1000)
        {
            //过滤区域边界框，使用轮廓找到弧长，true为轮廓封闭
            float peri = arcLength(contours[i], true);
            //找到曲线近似值，定义新数组
            approxPolyDP(contours[i], conPoly[i], 0.02 * peri, true);
            
            //边界矩阵和
            cout << conPoly[i].size() << endl;
            boundRect[i] = boundingRect(conPoly[i]);
            myPoint.x = boundRect[i].x + boundRect[i].width/2;
            myPoint.y = boundRect[i].y;
            
            //画轮廓，2为厚度
            drawContours(img, conPoly, i, Scalar(255, 0, 255), 2);
            rectangle(img, boundRect[i].tl(), boundRect[i].br(),  Scalar(0,255, 0), 5);

        }
    }
    return myPoint;
}

vector<vector<int>> findColor(Mat img)
{
    Mat imgHSV;
    cvtColor(img, imgHSV, COLOR_BGR2HSV);

    //寻找遮罩
    for(int i = 0; i < myColors.size(); i++)
    {
        Scalar lower(myColors[i][0], myColors[i][1], myColors[i][2]);
        Scalar upper(myColors[i][3], myColors[i][4], myColors[i][5]);
        Mat mask;
        inRange(imgHSV,lower,upper, mask);
        //imshow(to_string(i), mask);
        //获得轮廓
        Point myPoint = getContours(mask);
        //记录点以及它的颜色
        if (myPoint.x != 0 && myPoint.y != 0)
        {
            newPoints.push_back({myPoint.x, myPoint.y, i});
        }        
    }
    return newPoints;
}




int main(){

   //       string path = "../videos/1_red_standard.mp4"; 
    string path = "../videos/3_low_red.mp4";
    VideoCapture cap(path);

    while (true){

 
        cap.read(img);
        newPoints = findColor(img);

        imshow("Image",img);         
        waitKey(1);            
     
    }
    return 0;                     
    
}


#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>

using namespace cv;
using namespace std;

class Detector {
public:
    Detector(const string& videoPath, double fanRadius, double fanRPM, double projectileSpeed)
            : fanRadius(fanRadius), fanRPM(fanRPM), projectileSpeed(projectileSpeed) {
        cap.open(videoPath);
        if (!cap.isOpened()) {
            cerr << "打开文件失败" << endl;
            exit(EXIT_FAILURE);
        }
    }

    void detect() {
        while (true) {
            cap.read(img);
            if (img.empty()) {
                cerr << "Finish." << endl;
                break;
            }
            //预处理图像
            preprocessImage();
            //画出边框并且预测方向
            findAndDrawContours();
            imshow("Image", img);

            waitKey(1);

        }
    }

private:
    VideoCapture cap;
    Mat img, mask, imgGray, imgBlur, imgCanny, imgDil, imgThre, imgCon;
    double fanRadius, fanRPM, projectileSpeed;

    void preprocessImage() {
        Scalar lowerBound(200, 200, 200); // 白色的下限值
        Scalar upperBound(255, 255, 255); // 白色的上限值
        //将符合范围的部分设置为白色，其余部分设置为黑色
        inRange(img, lowerBound, upperBound, mask);
        Mat result;
        //保留white部分
        bitwise_and(img, img, result, mask);
        //转换为灰度图像
        cvtColor(result, imgGray, COLOR_BGR2GRAY);
        //模糊
        GaussianBlur(imgGray, imgBlur, Size(3, 3), 3, 0);
        //找边缘
        Canny(imgBlur, imgCanny, 25, 75);
        Mat kernel = getStructuringElement(MORPH_RECT, Size(3, 3));
        dilate(imgCanny, imgDil, kernel);
    }

    void findAndDrawContours() {
        vector<vector<Point>> contours;
        vector<Vec4i> hierarchy;
        findContours(imgDil, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        for (int i = 0; i < contours.size(); i++) {
            int area = contourArea(contours[i]);
            // cout << area << endl;
            //高于600才画轮廓
            if (area > 600) {
                vector<Point> approx;
                //过滤区域边界框，使用轮廓找到弧长，true为轮廓封闭
                float peri = arcLength(contours[i], true);
                //找最小旋转矩形
                approxPolyDP(contours[i], approx, 0.02 * peri, true);

                RotatedRect rect = minAreaRect(approx);
                if (area > 5000) {
                    //画边框
                    drawRotatedRect(rect);
                    calculateRotationDirection(rect);
                } else {
                    drawCenterPoint(rect);
                }
            }
        }
    }

    void drawRotatedRect(const RotatedRect& rect) {
        //绘制带有角度的矩形框
        Point2f points[4];
        rect.points(points);
        for (int j = 0; j < 4; j++) {
            line(img, points[j], points[(j + 1) % 4], Scalar(255, 0, 0), 2);
        }
        //输出坐标
        for (int j = 0; j < 4; j++) {
            cout << "点 " << j + 1 << ": (" << points[j].x << ", " << points[j].y << ")" << endl;
        }
    }
    //预测辨别旋转方向
    void calculateRotationDirection(const RotatedRect& rect) {
        float angle = rect.angle;
        double angularVelocity = fanRPM * 2 * CV_PI / 60;
        double fanLinearVelocity = fanRadius * angularVelocity;
        string rotationDirection = (fanLinearVelocity >= projectileSpeed) ? "顺时针" : "逆时针";
        cout << "旋转方向: " << rotationDirection << endl;
    }
    //画中心点
    void drawCenterPoint(const RotatedRect& rect) {
        Point2f center = rect.center;
        circle(img, center, 5, Scalar(0, 255, 0), -1);
    }
};

int main() {
    string path = "../videos/1_red_standard.mp4";
    //转速10，半径30，子弹射速1
    Detector Detector(path, 10, 30, 1);
    Detector.detect();

    return 0;
}



